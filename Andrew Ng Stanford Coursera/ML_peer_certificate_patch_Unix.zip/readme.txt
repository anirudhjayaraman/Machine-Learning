This patch fixes the "Peer certificate" issue with the submit.m script for linux-like systems (MacOS, etc).
This patch is an adjustment by Daniel Lawrence Lu to the patch that was developed by Liran Moysi.

Instructions:
1) Copy the file "submitWithConfiguration.m" to the "../ex?/lib" folder for each programming exercise.
This will overwrite the existing file.
2) Restart Octave or MATLAB after installing the patch.
